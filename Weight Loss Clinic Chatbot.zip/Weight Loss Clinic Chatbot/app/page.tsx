import { ChatBot } from '@/components/ChatBot';

export default function Home() {
  return (
    <>
      {/* Your existing page content */}
      <ChatBot />
    </>
  );
}

